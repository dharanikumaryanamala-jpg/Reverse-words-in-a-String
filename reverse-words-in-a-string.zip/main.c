/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<string.h>
int main()
{
    char s[100],temp[50][50];
    int count=0,k=0;
    scanf("%[^\n]s",s);
    for(int i=0;s[i];i++)
    {
        if(s[i]=='\n'||s[i]==' ')
        {
            temp[count][k]='\0';
            count++;
            k=0;
        }
        else
        temp[count][k++]= s[i];
    }
    temp[count][k]='\0';
    for(int i=count;i>=0;i--)
    {
        printf("%s ",temp[i]);
    }
    printf(" ");
}
